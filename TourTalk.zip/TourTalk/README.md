# TourTalk AI Chat

This project is a travel chatbot UI built in HTML/CSS/JavaScript. The chat uses OpenRouter with the DeepSeek model `deepseek/deepseek-v4-flash`.

## What works
- `project.html` is the main UI.
- `script.js` now sends chat requests to OpenRouter at `https://openrouter.ai/api/v1/chat/completions`.
- The OpenRouter API key is set in `script.js`.
- The model used is `deepseek/deepseek-v4-flash`.
- A quick verification run using `test_openrouter.js` returned `status 200 OK`.

## Files
- `project.html` — main landing page with chat interface.
- `style.css` — project styles.
- `script.js` — chat integration and application logic.
- `script1.js` — login/register toggle logic.
- `test_openrouter.js` — temporary script for API validation.
- `README.md` — this file.

## How to run

### Option 1: Open in browser
1. Open `project.html` in your web browser.
2. Navigate to the AI Chat page.
3. Type a message in the chat input and send.

### Option 2: Run through a local server (recommended)
1. Open a terminal in `c:\Users\ASUS\Desktop\TourTalk`.
2. Run a simple server:
   - Python: `python -m http.server 8000`
   - Or Node: `npx http-server .`
3. Open `http://localhost:8000/project.html`.

### Quick test & run commands

Run these commands inside the project folder (`c:\Users\ASUS\Desktop\TourTalk`).

1) Check JavaScript syntax for `script.js`:

```bash
node -c script.js
```

2) Verify OpenRouter connectivity (this sends a quick test request using the temporary test file):

```bash
node test_openrouter.js
```

Expected: `status 200 OK` and an assistant message in the printed JSON.

3) Start a local static server (serves the project at http://localhost:8000):

```bash
# using Python 3
python -m http.server 8000

# or with Node (if you have http-server installed)
npx http-server .
```

4) Open the app in your browser:

```
http://localhost:8000/project.html
```

Notes:
- The API key is present in `script.js` for quick testing. For production, move API calls to a secure backend proxy to avoid exposing the key in the browser.
- If you see CORS or network errors in the browser console, use the local server above (browsers often block `file://` requests to remote APIs).

## API and model details
- API endpoint: `https://openrouter.ai/api/v1/chat/completions`
- Authorization: `Bearer sk-or-v1-...`
- Model: `deepseek/deepseek-v4-flash`
- Message format: OpenRouter expects `messages` with `role` and text `content`.

## Validation
The temporary test file `test_openrouter.js` confirmed:
- OpenRouter key is valid.
- Model ID `deepseek/deepseek-v4-flash` is valid.
- The service responded with `200 OK` and returned a chat assistant message.

## Important note
The API key is currently stored directly in `script.js`. This is fine for quick testing but not secure for public deployment. For production, move the key to a backend proxy or server-side environment.

## If chat does not work
- Check browser console for CORS or network errors.
- Ensure `script.js` still has the OpenRouter key and endpoint.
- If the browser blocks the request, use a local server or backend proxy.
