const API_KEY='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';
const API_URL='https://openrouter.ai/api/v1/chat/completions';
let history=[];
let busy=false;
let pendingQ='';

const SYSTEM=`You are TourTalk AI — a premium, intelligent Indian travel assistant. You are calm, knowledgeable, articulate, and warm — like a well-travelled local friend with expert knowledge of India.

Your role is to guide Indian travellers step-by-step through their entire journey:
1. First ask for their destination in India
2. Ask for their total budget in INR
3. Ask how many days they plan to travel
4. Ask their preferred travel mode (flight/train/bus/cab)
5. Suggest the best routes with approximate INR prices
6. Recommend hotels within budget (with price per night)
7. List top tourist attractions nearby
8. Suggest local restaurants and must-try dishes
9. Calculate recommended days needed
10. Generate a complete day-by-day itinerary
11. Provide safety tips and local insights
12. Plan the return journey home

Guidelines:
- Always use ₹ INR for all prices
- Reference real Indian trains (IRCTC), airlines (IndiGo, Air India, SpiceJet, Vistara), and bus operators
- Mention specific Indian landmarks, cuisine, and cultural experiences
- Keep responses well-structured but conversational
- Use occasional Hindi phrases naturally (Namaste, Bilkul, Wah, etc.)
- Format clearly with line breaks for readability
- After each response, guide the user to the next step naturally
- Be concise — 3-5 paragraphs max per response`;

function openRouterMessage(role, text){
  return {role, content:text};
}

function parseResponse(data){
  const message = data?.choices?.[0]?.message;
  if(!message) return null;
  return typeof message.content === 'string'
    ? message.content
    : Array.isArray(message.content)
      ? message.content.map(item => item.text || '').join('')
      : null;
}

function showPage(p){
  document.querySelectorAll('.nav-pill').forEach((el,i)=>{
    el.classList.toggle('active',['home','planner','chat'][i]===p);
  });
  document.getElementById('home-page').classList.toggle('active',p==='home');
  document.getElementById('planner-page').classList.toggle('active',p==='planner');
  document.getElementById('chat-page').classList.toggle('active',p==='chat');
  if(p==='chat'&&history.length===0) initChat();
  if(pendingQ&&p==='chat'){
    document.getElementById('chatIn').value=pendingQ;
    pendingQ='';
  }
}

function setDestAndChat(dest){
  pendingQ=`I want to plan a trip to ${dest}`;
  showPage('chat');
  setTimeout(()=>{
    document.getElementById('chatIn').value=`I want to plan a trip to ${dest}`;
  },100);
}

function setQ(q){
  document.getElementById('chatIn').value=q;
  document.getElementById('chatIn').focus();
}

let darkMode=false;
function toggleDark(){
  darkMode=!darkMode;
  document.body.classList.toggle('dark',darkMode);
  document.querySelector('.dark-toggle').textContent=darkMode?'🌙':'☀️';
}

function updateBudget(){
  const v=parseInt(document.getElementById('budgetSlider').value);
  document.getElementById('budgetDisplay').textContent='₹'+v.toLocaleString('en-IN');
  renderBreakdown(v);
}
function updateDays(){
  const v=parseInt(document.getElementById('daysSlider').value);
  document.getElementById('daysDisplay').textContent=v+' day'+(v>1?'s':'');
}
function renderBreakdown(budget){
  const el=document.getElementById('budgetBreakdown');
  if(!el)return;
  const cats=[
    {label:'Transport',pct:35,color:'#0EA5E9'},
    {label:'Hotels',pct:40,color:'#6366F1'},
    {label:'Food',pct:15,color:'#10B981'},
    {label:'Activities',pct:10,color:'#F59E0B'}
  ];
  el.innerHTML=cats.map(c=>{
    const amt=Math.round(budget*c.pct/100);
    return `<div style="display:flex;align-items:center;gap:10px">
      <div style="width:10px;height:10px;border-radius:3px;background:${c.color};flex-shrink:0"></div>
      <div style="flex:1;font-size:.82rem;color:var(--ink)">${c.label}</div>
      <div style="font-size:.82rem;font-weight:600;color:var(--ink)">₹${amt.toLocaleString('en-IN')}</div>
      <div style="width:80px;height:4px;background:var(--border);border-radius:2px;overflow:hidden"><div style="height:100%;width:${c.pct}%;background:${c.color};border-radius:2px"></div></div>
    </div>`;
  }).join('');
}
renderBreakdown(15000);

async function initChat(){
  setLoading(true);
  try{
    history = [openRouterMessage('system', SYSTEM)];
    const starter = 'Hello, I want to plan a trip in India';
    history.push(openRouterMessage('user', starter));

    const res = await fetch(API_URL, {
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'Authorization':'Bearer '+API_KEY
      },
      body:JSON.stringify({
        model:'deepseek/deepseek-v4-flash',
        messages: history,
        temperature:0.7,
        top_p:0.95,
        max_tokens:1200
      })
    });

    const d = await res.json();
    const txt = parseResponse(d) || fallbackGreet();
    history.push(openRouterMessage('assistant', txt));
    setLoading(false);
    addMsg('ai', txt);
  }catch(err){
    console.error(err);
    setLoading(false);
    addMsg('ai', fallbackGreet());
  }
}

function fallbackGreet(){
  return `Namaste! 🙏 Welcome to TourTalk — I'm your personal AI travel companion for India.\n\nI'm here to help you plan the perfect journey, from choosing your destination to booking your return trip home. I'll handle routes, hotels, budgets, and day-by-day itineraries — all optimised for Indian travel.\n\nLet's begin — which part of incredible India are you dreaming of visiting? 🇮🇳`;
}

async function sendMsg(){
  const inp=document.getElementById('chatIn');
  const txt=inp.value.trim();
  if(!txt||busy)return;
  inp.value='';
  addMsg('user',txt);
  history.push(openRouterMessage('user', txt));
  setLoading(true);
  try{
    const res = await fetch(API_URL, {
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'Authorization':'Bearer '+API_KEY
      },
      body:JSON.stringify({
        model:'deepseek/deepseek-v4-flash',
        messages: history,
        temperature:0.7,
        top_p:0.95,
        max_tokens:1200
      })
    });

    const d = await res.json();
    const reply = parseResponse(d) || 'Sorry, I had a small issue. Please try again!';
    history.push(openRouterMessage('assistant', reply));
    setLoading(false);
    addMsg('ai', reply);
  }catch(err){
    console.error(err);
    setLoading(false);
    addMsg('ai','I\'m having a brief connection issue. Please try again in a moment — I\'m here to help plan your trip! 🙏');
  }
}

let loadEl=null;
function setLoading(on){
  busy=on;
  document.getElementById('sendBtn').disabled=on;
  const c=document.getElementById('chatMsgs');
  if(on){
    loadEl=document.createElement('div');
    loadEl.className='msg';
    loadEl.innerHTML=`<div class="msg-av ai">T</div><div class="bubble ai"><div class="loading-msg"><div class="ld-dot"></div><div class="ld-dot"></div><div class="ld-dot"></div></div></div>`;
    c.appendChild(loadEl);c.scrollTop=c.scrollHeight;
  }else if(loadEl){loadEl.remove();loadEl=null}
}

function addMsg(role,text){
  const c=document.getElementById('chatMsgs');
  const d=document.createElement('div');
  d.className=`msg ${role}`;
  const av=document.createElement('div');
  av.className=`msg-av ${role}`;
  av.textContent=role==='ai'?'T':'U';
  const b=document.createElement('div');
  b.className=`bubble ${role}`;
  b.innerHTML=fmt(text);
  d.appendChild(av);d.appendChild(b);
  c.appendChild(d);c.scrollTop=c.scrollHeight;
}

function fmt(t){
  return t
    .replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')
    .replace(/₹([\d,]+)/g,'<span class="price">₹$1</span>')
    .replace(/\n/g,'<br>');
}

let micOn=false;
function toggleMic(){
  const btn=document.getElementById('micBtn');
  if(micOn){
    micOn=false;btn.classList.remove('on');
    if(window._sr)window._sr.stop();
  }else{
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){alert('Voice input not supported. Please type your message.');return}
    const r=new SR();
    r.lang='hi-IN';r.continuous=false;r.interimResults=false;
    r.onresult=e=>{document.getElementById('chatIn').value=e.results[0][0].transcript;micOn=false;btn.classList.remove('on')};
    r.onerror=()=>{micOn=false;btn.classList.remove('on')};
    r.start();window._sr=r;micOn=true;btn.classList.add('on');
  }
}