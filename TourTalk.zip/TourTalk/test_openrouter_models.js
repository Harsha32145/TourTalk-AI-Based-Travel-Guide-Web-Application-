const fetch = global.fetch || require('node-fetch');
const API_KEY = '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';
const API_URL = 'https://openrouter.ai/api/v1/models';
(async () => {
  try {
    const res = await fetch(API_URL, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      }
    });
    console.log('status', res.status, res.statusText);
    const data = await res.json();
    console.log(JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('error', err);
  }
})();
