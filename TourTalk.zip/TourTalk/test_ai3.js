const API_KEY = 'AIzaSyDLbyDyPwBQloKKFIMBVrAuHR3sxiDZfnw';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta2/models/chat-bison@001:generateMessage?key=' + API_KEY;
(async () => {
  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        temperature: 0.7,
        max_output_tokens: 128,
        top_p: 0.95,
        top_k: 40,
        candidate_count: 1,
        prompt: {
          messages: [
            {author: 'system', content: 'You are a friendly travel assistant.'},
            {author: 'user', content: 'Hello, how are you?'}]
        }
      })
    });
    console.log('status', res.status, res.statusText);
    const text = await res.text();
    console.log('body', text);
  } catch (err) {
    console.error('error', err);
  }
})();
